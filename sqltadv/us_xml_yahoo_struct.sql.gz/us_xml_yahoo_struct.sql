-- phpMyAdmin SQL Dump
-- version 3.0.1
-- http://www.phpmyadmin.net
--
-- Host: remote-mysql4.servage.net
-- Generation Time: Mar 06, 2009 at 05:45 AM
-- Server version: 5.0.67
-- PHP Version: 5.2.42-servage7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `scrapping1`
--

-- --------------------------------------------------------

--
-- Table structure for table `us_xml_yahoo`
--

CREATE TABLE IF NOT EXISTS `us_xml_yahoo` (
  `id` int(11) NOT NULL auto_increment,
  `hotel_id` int(11) NOT NULL default '0',
  `xmlpath` varchar(255) default NULL,
  `data` text,
  `flag` int(1) NOT NULL default '0',
  `ftype` varchar(100) character set ucs2 NOT NULL,
  `province` varchar(10) character set ucs2 default NULL,
  `baseurl` text,
  `baseurlflag` int(1) NOT NULL default '0',
  `firsturl` text,
  `firsturlflag` int(1) NOT NULL default '0',
  `gotpoi` int(1) NOT NULL default '0',
  `reviewurl` text,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=42756 ;
