-- phpMyAdmin SQL Dump
-- version 3.0.1
-- http://www.phpmyadmin.net
--
-- Host: remote-mysql4.servage.net
-- Generation Time: Mar 06, 2009 at 05:37 AM
-- Server version: 5.0.67
-- PHP Version: 5.2.42-servage7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `scrapping1`
--

-- --------------------------------------------------------

--
-- Table structure for table `poi_detail`
--

CREATE TABLE IF NOT EXISTS `poi_detail` (
  `id` int(11) NOT NULL auto_increment,
  `poi_id` int(11) NOT NULL,
  `poi_name` varchar(255) collate latin1_general_ci default NULL,
  `reviewer` varchar(255) collate latin1_general_ci default NULL,
  `reviewdate` varchar(50) collate latin1_general_ci default NULL,
  `review_title` varchar(100) collate latin1_general_ci default NULL,
  `rating` varchar(20) collate latin1_general_ci default NULL,
  `review_detail` text collate latin1_general_ci,
  `source` text collate latin1_general_ci,
  `filename` text collate latin1_general_ci,
  `targetSite` varchar(255) collate latin1_general_ci default NULL,
  `avgrating` varchar(20) collate latin1_general_ci default NULL,
  `xml_id` int(11) default NULL,
  `province` varchar(50) collate latin1_general_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=126716 ;
