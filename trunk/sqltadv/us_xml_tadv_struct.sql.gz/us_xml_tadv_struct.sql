-- phpMyAdmin SQL Dump
-- version 3.0.1
-- http://www.phpmyadmin.net
--
-- Host: remote-mysql4.servage.net
-- Generation Time: Mar 06, 2009 at 05:48 AM
-- Server version: 5.0.67
-- PHP Version: 5.2.42-servage7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `scrapping1`
--

-- --------------------------------------------------------

--
-- Table structure for table `us_xml_tadv`
--

CREATE TABLE IF NOT EXISTS `us_xml_tadv` (
  `id` int(11) NOT NULL auto_increment,
  `xmlpath` varchar(255) default NULL,
  `data` text,
  `flag` int(1) NOT NULL default '0',
  `ftype` varchar(100) character set ucs2 NOT NULL,
  `province` varchar(10) character set ucs2 default NULL,
  `baseurl` text,
  `baseurlflag` int(1) NOT NULL default '0',
  `firsturl` text,
  `firsturlflag` int(1) NOT NULL default '0',
  `otherurls` text,
  `otherurlsflag` int(1) NOT NULL default '0',
  `fetchotherurls` int(1) NOT NULL default '0',
  `reviewallflag` int(1) NOT NULL default '0',
  `gothotel` int(1) NOT NULL default '0',
  `totaltreview` int(11) NOT NULL default '0',
  `heading` varchar(255) default NULL,
  `avgrating` varchar(50) default NULL,
  `xtra` text,
  `xtra2` text,
  `transfer` int(1) NOT NULL default '0',
  `hotel_id` int(11) NOT NULL default '0',
  `check_done` tinyint(1) NOT NULL default '0',
  `check_review` int(11) NOT NULL default '0',
  `check_nomatch` tinyint(1) NOT NULL default '0',
  `check_nofile` tinyint(1) NOT NULL default '0',
  `new_avg_rating` float(12,2) default NULL,
  `check2_flag` int(1) NOT NULL default '0',
  `check2_done` int(1) NOT NULL default '0',
  `checkprocess` tinyint(1) NOT NULL default '0',
  `check3_done` tinyint(1) NOT NULL default '0',
  `check3_review` int(11) NOT NULL default '0',
  `check3_nomatch` tinyint(1) NOT NULL default '0',
  `check3_nofile` tinyint(1) NOT NULL default '0',
  `new_avg_rating2` float(12,2) NOT NULL default '0.00',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=49478 ;
